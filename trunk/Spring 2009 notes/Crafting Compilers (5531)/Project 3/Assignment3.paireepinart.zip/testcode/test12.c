/* constant folding */
int foo() {
  int x;
  x = 17 + 2 * 3;
}
