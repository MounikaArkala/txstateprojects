/* function signature mismatch - too many parameters : line 7 */
int foo(int i) {
  return 0;
}

int bar() {
  foo(1, 2);
}

