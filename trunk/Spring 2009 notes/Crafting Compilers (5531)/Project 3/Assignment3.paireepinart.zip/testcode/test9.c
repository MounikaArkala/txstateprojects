/* scoping rules : shadow variable */ 
int i;

int foo(int i) {
  return 0;
}



