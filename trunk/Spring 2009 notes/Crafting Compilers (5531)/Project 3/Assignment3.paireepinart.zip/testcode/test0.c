int foo() {
  int i;
  int k;
  int i;
} 
