/* simple type mismatch : line 5 */
int foo() {
  int i;
  char c;
  c = i;
}
