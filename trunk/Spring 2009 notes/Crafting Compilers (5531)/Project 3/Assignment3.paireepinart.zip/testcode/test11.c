/* scoping rules - formal parameter accessed outside scope : line 7 */
int foo(int i) {
  return 0;
}

int bar() {
  i = 17;
  return 0;
}
