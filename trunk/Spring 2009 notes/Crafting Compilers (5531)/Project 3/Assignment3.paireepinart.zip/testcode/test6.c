/* function signature mismatch - too few parameters : line 7 */
int foo(int i) {
  return 0;
}

int bar() {
  foo();
}

