/* illegal array reference : line 7 */ 
int foo() {
  int a[17];

  char c;

  a[c];
}
