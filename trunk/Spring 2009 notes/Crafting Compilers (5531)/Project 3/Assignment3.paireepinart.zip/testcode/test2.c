/* undefined function error : line 6 */
int foo() {
  int i;
  int k;

  bar();
} 

