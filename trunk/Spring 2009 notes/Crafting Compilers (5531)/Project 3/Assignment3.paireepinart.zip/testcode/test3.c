/* multiply defined function error : line 6 */
int foo() {
  return 0;
}

int foo() {
  int i;
  int k;
} 

