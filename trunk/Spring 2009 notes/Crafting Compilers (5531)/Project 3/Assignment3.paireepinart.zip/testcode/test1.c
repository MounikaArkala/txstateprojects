/* undeclared variable error : line 6 */
int foo() {
  int i;
  int k;
  
  j = 17;
} 

