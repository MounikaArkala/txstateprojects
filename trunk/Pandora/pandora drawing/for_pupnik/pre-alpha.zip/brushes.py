

class Brush(object):
    def __init__(self, color, radius, transparency):
        self.color = color
        self.radius = radius
        self.transparency = transparency