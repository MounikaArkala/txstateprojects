int i[5];
int i;
int somefunc(int i)
{
    return i + 1;
}