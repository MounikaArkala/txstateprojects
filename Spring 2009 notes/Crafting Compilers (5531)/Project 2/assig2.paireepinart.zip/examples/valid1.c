


/*  Some multiline comment */
int func()
{
    i = 5;
    return 1;
}

int main(int j, int k)
{
    while (1)
    {
            j = 100;
            printf("Somestring");
    }
}