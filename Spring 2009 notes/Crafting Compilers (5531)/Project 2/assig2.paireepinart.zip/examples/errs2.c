/*  This includes unterminated semicolons and other random syntax errors. */

int func()
{
    int;
    i =;
    return [1];
