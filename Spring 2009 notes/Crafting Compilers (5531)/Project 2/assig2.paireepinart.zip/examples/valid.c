


/*  Some multiline comment */
int func()
{
    /*int i;*/
    i = 5;
    return 1;
}

int foo[6];

int main(int j, int k)
{
    char c;
    int j;
    j = 0;
    while (j < 256)
    {
            j = j + 1;
            c = itoa(j);
            putch(c);
    }
    return;
}