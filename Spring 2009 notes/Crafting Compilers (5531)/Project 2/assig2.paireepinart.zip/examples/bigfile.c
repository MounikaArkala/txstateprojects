/*  This is just an example of a big, syntactically-correct file being parsed.
    Has examples for every grammar rule. */

int func()
{
    int i;
    i = 5;
    return 1;
}


int foo[6];

int main(int j, int k)
{
    char c;
    j = 0;
    if (j < 0)
    {
        j = 256 - min(abs(j), 256);
    }
    else
    {
        j = 0;
    }
    
    while (j < 256)
    {
            j = j + 1;
            c = itoa(j);
            putch(c);
    }
    return j;
}
int jeff()
{
    int b;
    string jdawg;
    jdawg = "\t\nJeff!";
    printf(jdawg);
    return;
    /* some random comment." */
}